﻿using UnityEngine;
using System.Collections;

public class BackgroundMover : MonoBehaviour {

    public int numOfObjects;
    public bool isBG;
    public ObstacleController[] obstacle;

    private Collider2D myCollider;
    private float semakX;
    private float kelelawarX;

    void Start()
    {
        myCollider = GetComponent<Collider2D>();
        obstacle = FindObjectsOfType<ObstacleController>();
        //Debug.Log(obstacle.Length);
    }

    void OnTriggerEnter2D(Collider2D collider)
    {
        bool first = true;
        //Debug.Log("Triggered " + collider.name);
        //Debug.Log(collider.gameObject.tag);
        if (collider.gameObject.tag=="killTag")
        {
            for (int i = 0; i < obstacle.Length; i++)
            {
                if(collider.name == "semak")
                {
                    semakX = semakX < obstacle[i].transform.position.x ? obstacle[i].transform.position.x : semakX;
                }else
                {
                    kelelawarX = kelelawarX < obstacle[i].transform.position.x ? obstacle[i].transform.position.x : kelelawarX;
                }
            }
            ObstacleController tmp = collider.GetComponentInParent<ObstacleController>();
            if (first)
            {
                tmp.setX(FindObjectOfType<PlayerController>().transform.position.x);
                tmp.move();
                first = false;
                return;
            }
            tmp.move();
            if (collider.name == "semak")
            {
                tmp.setX(semakX);
                semakX = tmp.transform.position.x;

            }else
            {
                tmp.setX(kelelawarX);
                kelelawarX = tmp.transform.position.x;
            }
        }
        else if(collider.gameObject.tag == "BG")
        {
            collider.GetComponentInParent<BackgroundController>().move();
        }else
        {
            collider.GetComponentInParent<BorderController>().move();
        }
    }
}